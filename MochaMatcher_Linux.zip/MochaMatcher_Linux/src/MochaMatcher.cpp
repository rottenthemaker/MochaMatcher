#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char * argv[]) {
    string temp = "";
    if (argc == 2) { //check for flags
        temp = argv[1];
        if (temp != "-r") {
            cout << "Improper flag usage. Use \"MochaMatcher -r\" to reset settings, otherwise put no flags after program name." << endl;
            return -3; //-3 error code means improper flag usage.
        }
    }
    
    int numOfWorkers = -1, counter = -1, place = -1;
    bool firstTime;
    fstream counterVar("MochaMatcherData");//todo add price calculator and defensive programming
    if (!counterVar.is_open()) { //check if file pointer is proerly opened
        cout << "Error, data file not found. Please reinstall MochaMatcher! (Warning, this will reset co-worker payment logic and you will need to start again.)" << endl;
        return -1; //error code -1 means data file not found/corrupted.
    }
    cout << "Hello and welcome to MochaMatcher! Let's find out who will be paying today.\n";
    counterVar >> temp;
    if (temp == "0" || temp == "1") {
        //do nothing, continue
    } else {
        cout << "Error, data file corrupted. Please reinstall MochaMatcher! (Warning, this will reset co-worker payment logic and you will need to start again.)" << endl;
        return -1;
    }
    counterVar.seekg(0);
    counterVar >> firstTime;
    if (firstTime || temp == "-r") { //check if first time program run or resetting settings
        counterVar.close();
        
        cout << "It looks like this is your first time using MochaMatcher! Let's get you set up.\nHow many co-workers will be buying coffee?\n";
        while (!(cin >> numOfWorkers)) { //check for proper input (int) and loop until user inputs correct input
            cin.clear();
            cin.ignore();
            cout << "Invalid input. Please input a number.\nHow many co-workers will be buying coffee?\n";
        }
        
        string * nameArray = new string[numOfWorkers]; //create new dynamic string array to hold names
        if (nameArray == nullptr) { //check if dynamic string pointer was initialized
            cout << "Not enough memory for application to run! Free up some meory and run MochaMatcher again." << endl;
            return -2; //error code -2 means not enough memory to allocate dynamic arrays.
        }
        double * priceTemp = new double[numOfWorkers];
        for (int i = 0; i < numOfWorkers; i++) {
            cout << "Enter coworker #" << i+1 << "'s name:\n"; //entering coworker names
            if (i == 0) cin.ignore();
            getline(cin,nameArray[i]);
            cout << "How much did " << nameArray[i] << "'s drink cost? (Put in price without dollar sign)" << endl;
            while (!(cin >> priceTemp[i]) || priceTemp[i] < 0) { //check for proper input for price (not negative, and is a decimal/integer)
                cin.clear();
                cin.ignore();
                cout << "Invalid input, please input a positive decimal number for the coffee price.\nHow much did " << nameArray[i] << "'s drink cost?" << endl;
            }
            cin.ignore();
        }
        counterVar.open("MochaMatcherData", ios::out);
        counterVar << "0\n" << numOfWorkers << "\n"; //insert firstTime bool and total num of workers into 
        for (int i = 0; i < numOfWorkers; i++) { //insert names into data file
            counterVar << nameArray[i] << " ";
        }
        counterVar << endl;
        for (int i = 0; i < numOfWorkers; i++) { //insert prices into data file
            counterVar << priceTemp[i] << " ";
        }
        counterVar << "\n1\n";
        cout << "MochaMatcher is now set up! If you need to change any of these settings, please use \"MochaMatcher -r\" to reset the program's data and start again.\nNow calculating who should pay today:" << endl;
        cout << "The person who is paying today is: " << nameArray[0] << endl; //first person to be entered into the cycle starts payment
        for (int i = 1; i < numOfWorkers; i++) {
            cout << nameArray[i] << " owes " << nameArray[0] << " $" << priceTemp[i] << endl;
        }
        delete[] priceTemp; //stop memory leaks
        delete[] nameArray;
        counterVar.close(); //close file pointer
        return 0;
    }
    //if user has already set up, code below is executed
    counterVar >> counter;
    string * nameTemp = new string[counter];
    double * priceTemp = new double[counter];
    for (int i = 0; i < counter; i++) { //get all names into nameTemp
        counterVar >> nameTemp[i];
    }
    for (int i = 0; i < counter; i++) { //get all prices into name temp
        counterVar >> priceTemp[i];
    }
    counterVar >> place;
    if (place == counter) place = 0;
    cout << "The person who is paying today is: " << nameTemp[place] << endl;
    for (int i = 0; i < counter; i++) {
        if (i == place) continue; //skip over person who is already paying
        cout << nameTemp[i] << " owes " << nameTemp[place] << " $" << priceTemp[i] << endl;
    }
    place++; //increment for next person
    counterVar.close();
    counterVar.open("MochaMatcherData", ios::out);
    counterVar << "0\n" << counter << "\n";
    for (int i = 0; i < counter; i++) {
        counterVar << nameTemp[i] << " ";
    }
    counterVar << endl;
    for (int i = 0; i < counter; i++) { //insert prices into data file
        counterVar << priceTemp[i] << " ";
    }
    counterVar << "\n" << place << endl;
    delete[] nameTemp; //stop memory leaks
    delete[] priceTemp;
    counterVar.close(); //close file pointer
    return 0;
}

